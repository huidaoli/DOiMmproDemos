package com.can2do.doimmpro.login;

import android.os.Bundle;

import com.ab.activity.AbActivity;
import com.ab.view.titlebar.AbTitleBar;
import com.can2do.doimmpro.R;

public class UiAgreement extends AbActivity {

	private AbTitleBar mAbTitleBar = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setAbContentView(R.layout.agreement);

		mAbTitleBar = this.getTitleBar();
		mAbTitleBar.setTitleText(R.string.agreement_name);
		mAbTitleBar.setLogo(R.drawable.button_selector_back);
		mAbTitleBar.setTitleBarBackground(R.drawable.top_bg);
		mAbTitleBar.setTitleTextMargin(10, 0, 0, 0);
		mAbTitleBar.setLogoLine(R.drawable.line);
		this.setTitleBarOverlay(true);

	}

}
