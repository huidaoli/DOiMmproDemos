package com.can2do.doimmpro.main;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import com.ab.activity.AbActivity;
import com.ab.view.titlebar.AbBottomBar;
import com.ab.view.titlebar.AbTitleBar;
import com.can2do.doimmpro.R;
import com.can2do.doimmpro.base.BaseLJWebView;
import com.can2do.doimmpro.demo.global.Constant;
import com.can2do.doimmpro.demo.global.MyApplication;

public class UiLogin extends AbActivity {

	private MyApplication application;
	String version = null;
	private BaseLJWebView mLJWebView = null;
	private AbBottomBar mAbBottomBar = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setAbContentView(R.layout.ui_login);

		AbTitleBar mAbTitleBar = this.getTitleBar();
		mAbTitleBar.setTitleText(R.string.workspase);
		mAbTitleBar.setLogo(R.drawable.button_selector_back);
		mAbTitleBar.setTitleBarBackground(R.drawable.top_bg);
		mAbTitleBar.setTitleTextMargin(10, 0, 0, 0);
		mAbTitleBar.setLogoLine(R.drawable.line);
		// 设置AbTitleBar在最上
		this.setTitleBarOverlay(true);
		application = (MyApplication) abApplication;
		mAbTitleBar.getLogoView().setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						finish();
					}
		});
		
		mAbBottomBar = this.getBottomBar();
		mAbBottomBar.setVisibility(View.VISIBLE);
		View view = mInflater.inflate(R.layout.ui_message_bottom_bar, null);
		Button Btn1 = (Button) view.findViewById(R.id.tab_1);
		Button Btn2 = (Button) view.findViewById(R.id.tab_2);
		Button Btn3 = (Button) view.findViewById(R.id.tab_3);
		mAbBottomBar.setBottomView(view);
		
		Btn1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
//				Intent intent = new Intent(UiMessage.this,
//						UiAbout.class);
//				startActivity(intent);
			}
		});
		
		Btn2.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
//				Intent intent = new Intent(UiMessage.this,
//						UiAbout.class);
//				startActivity(intent);
			}
		});
		
		Btn3.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
//				Intent intent = new Intent(UiMessage.this,
//						UiAbout.class);
//				startActivity(intent);
			}
		});
		
		mLJWebView = (BaseLJWebView) findViewById(R.id.web);
		mLJWebView.setProgressStyle(BaseLJWebView.Circle);
		mLJWebView.setBarHeight(8);
		mLJWebView.setClickable(true);
		mLJWebView.setUseWideViewPort(false);
		mLJWebView.setSupportZoom(true);
		mLJWebView.setBuiltInZoomControls(true);
		mLJWebView.setJavaScriptEnabled(true);
		mLJWebView.setJavaScriptCanOpenWindowsAutomatically(true);
		mLJWebView.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		mLJWebView.setAppCacheEnabled(true);
		mLJWebView.setAppCacheMaxSize(1024 * 10);
		
		mLJWebView.setWebViewClient(new WebViewClient() {

			public boolean shouldOverrideUrlLoading(WebView view, String url) {

				System.out.println("跳的URL =" + url);

				view.loadUrl(url);
				return true;
			}
		});

		mLJWebView.loadUrl(Constant.my);
	}

}
