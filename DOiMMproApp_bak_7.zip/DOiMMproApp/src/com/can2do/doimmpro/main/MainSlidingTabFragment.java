package com.can2do.doimmpro.main;

import java.util.ArrayList;
import java.util.List;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;

import com.ab.view.sliding.AbSlidingTabView;
import com.can2do.doimmpro.R;

public class MainSlidingTabFragment extends Fragment {

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.tab_top, null);
		AbSlidingTabView mAbSlidingTabView = (AbSlidingTabView) view
				.findViewById(R.id.mAbSlidingTabView);

		// 缓存数量
		mAbSlidingTabView.getViewPager().setOffscreenPageLimit(5);

		MainDefault1Fragment page1 = new MainDefault1Fragment();
		MainDefault2Fragment page2 = new MainDefault2Fragment();
		MainDefault3Fragment page3 = new MainDefault3Fragment();
		MainDefault4Fragment page4 = new MainDefault4Fragment();
		MainDefault5Fragment page5 = new MainDefault5Fragment();
		MainDefault6Fragment page6 = new MainDefault6Fragment();
//		MainDefault7Fragment page7 = new MainDefault7Fragment();
//		MainDefault8Fragment page8 = new MainDefault8Fragment();
		
		List<Fragment> mFragments = new ArrayList<Fragment>();
		mFragments.add(page1);
		mFragments.add(page2);
		mFragments.add(page3);
		mFragments.add(page4);

		List<String> tabTexts = new ArrayList<String>();
		tabTexts.add("首页");
		tabTexts.add("餐饮");
		tabTexts.add("保健");
		tabTexts.add("器材");
		
		// 设置样式
		mAbSlidingTabView.setTabTextColor(Color.BLACK);
		mAbSlidingTabView.setTabSelectColor(Color.rgb(30, 168, 131));
		mAbSlidingTabView.setTabBackgroundResource(R.drawable.tab_bg);
		mAbSlidingTabView.setTabLayoutBackgroundResource(R.drawable.slide_top);
		// 演示增加一组
		mAbSlidingTabView.addItemViews(tabTexts, mFragments);

		// 演示增加一个
		mAbSlidingTabView.addItemView("礼品", page5);
		mAbSlidingTabView.addItemView("其他", page6);
//		mAbSlidingTabView.addItemView("其他", page7);
//		mAbSlidingTabView.addItemView("其他", page8);

		mAbSlidingTabView.setTabPadding(20, 8, 20, 8);
		return view;
	}

	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

}
