/** Automatically generated file. DO NOT MODIFY */
package com.can2do.doimmpro;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}