package com.can2do.doimmpro.demo.global;

public class Constant {

	public static final boolean DEBUG = true;
	public static final String sharePath = "andbase_share";
	public static final String USERSID = "user";
	// 页面默认显示南京，登陆后显示注册用户的城市
	public static final String CITYID = "cityId";
	public static final String CITYNAME = "cityName";
	public static final String DEFAULTCITYID = "1001";
	public static final String DEFAULTCITYNAME = "南京";

	// cookies
	public static final String USERNAMECOOKIE = "cookieName";
	public static final String USERPASSWORDCOOKIE = "cookiePassword";
	public static final String USERPASSWORDREMEMBERCOOKIE = "cookieRemember";
	public static final String ISFIRSTSTART = "isfirstStart";

	// 连接超时
	public static final int timeOut = 12000;
	// 建立连接
	public static final int connectOut = 12000;
	// 获取数据
	public static final int getOut = 60000;

	// 1表示已下载完成
	public static final int downloadComplete = 1;
	// 1表示未开始下载
	public static final int undownLoad = 0;
	// 2表示已开始下载
	public static final int downInProgress = 2;
	// 3表示下载暂停
	public static final int downLoadPause = 3;

	// public static final String BASE = "http://mmproapp.we2line.com";
	public static final String BASE = "http://m.mm2oo.com:805";
	//public static final String BASE = "http://192.168.18.133:8011";
	public static final String type1 = BASE + "/product/explore/types1";
	public static final String type2 = BASE + "/product/explore/types2";
	public static final String type3 = BASE + "/product/explore/types3";
	public static final String type4 = BASE + "/product/explore/types4";
	public static final String other = BASE + "/product/explore/other";

	public static final String article = BASE + "/article";
	public static final String hangyei = BASE + "/article/category/hangyei";
	public static final String yeiwu = BASE + "/article/category/yeiwu";

	public static final String search = BASE + "/search";

	public static final String notification = BASE + "/notification";
	public static final String message = BASE + "/message";

	public static final String logout = BASE + "/logout";
	public static final String login = BASE + "/login";
	public static final String my = BASE + "/my";

	public static final String settings = BASE + "/settings";

	public static final String BASEURL = "http://www.amsoft.cn/";

	// 应用的key
	// 1512528
	public final static String APPID = "1512528";

	// jfa97P4HIhjxrAgfUdq1NoKC
	public final static String APIKEY = "jfa97P4HIhjxrAgfUdq1NoKC";

}
