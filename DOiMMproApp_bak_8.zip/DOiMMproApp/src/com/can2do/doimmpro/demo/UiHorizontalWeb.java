package com.can2do.doimmpro.demo;

import com.can2do.doimmpro.R;
import com.can2do.doimmpro.base.BaseLJWebView;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class UiHorizontalWeb extends Activity {

	private BaseLJWebView mLJWebView = null;
	private String url = "http://mmpro.we2line.com";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_horizontal_web);

		mLJWebView = (BaseLJWebView) findViewById(R.id.web);
		mLJWebView.setBarHeight(8);
		mLJWebView.setClickable(true);
		mLJWebView.setUseWideViewPort(false);
		mLJWebView.setSupportZoom(true);
		mLJWebView.setBuiltInZoomControls(true);
		mLJWebView.setJavaScriptEnabled(true);
		mLJWebView.setCacheMode(WebSettings.LOAD_NO_CACHE);
		mLJWebView.setAppCacheEnabled(true);
		mLJWebView.setAppCacheMaxSize(1024 * 10);
		mLJWebView.setWebViewClient(new WebViewClient() {

			public boolean shouldOverrideUrlLoading(WebView view, String url) {

				System.out.println("跳的URL =" + url);

				view.loadUrl(url);
				return true;
			}
		});

		mLJWebView.loadUrl(url);

	}
}