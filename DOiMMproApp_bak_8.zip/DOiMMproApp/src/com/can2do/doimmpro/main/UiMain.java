package com.can2do.doimmpro.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.ab.activity.AbActivity;
import com.ab.db.storage.AbSqliteStorage;
import com.ab.util.AbLogUtil;
import com.ab.util.AbMonitorUtil;
import com.ab.view.slidingmenu.SlidingMenu;
import com.ab.view.titlebar.AbBottomBar;
import com.ab.view.titlebar.AbTitleBar;

import com.can2do.doimmpro.R;
import com.can2do.doimmpro.login.UiLogin;
import com.can2do.doimmpro.main.MainSlidingTabFragment;

public class UiMain extends AbActivity {

	private SlidingMenu menu;
	private AbTitleBar mAbTitleBar = null;
	private AbBottomBar mAbBottomBar = null;

	// 数据库操作类
	public AbSqliteStorage mAbSqliteStorage = null;

	private MainMenuFragment mMainMenuFragment = null;
	private MainSlidingTabFragment mMainSlidingTabFragment = null;

	public final int LOGIN_CODE = 0;
	public final int FRIEND_CODE = 1;
	public final int CHAT_CODE = 2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setAbContentView(R.layout.sliding_menu_content);

		// 顶部标题栏
		mAbTitleBar = this.getTitleBar();
		mAbTitleBar.setTitleText(R.string.app_name);
		mAbTitleBar.setLogo(R.drawable.button_selector_menu);
		mAbTitleBar.setTitleBarBackground(R.drawable.top_bg);
		mAbTitleBar.setTitleTextMargin(10, 0, 0, 0);
		mAbTitleBar.setLogoLine(R.drawable.line);

		// 底部标题栏
		mAbBottomBar = this.getBottomBar();
		mAbBottomBar.setVisibility(View.VISIBLE);
		View view = mInflater.inflate(R.layout.ui_product_bottom_bar, null);
		Button Btn1 = (Button) view.findViewById(R.id.tab_1);
		Button Btn2 = (Button) view.findViewById(R.id.tab_2);
		Button Btn3 = (Button) view.findViewById(R.id.tab_3);
		Button Btn4 = (Button) view.findViewById(R.id.tab_4);
		mAbBottomBar.setBottomView(view);
		Btn1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Intent intent = new Intent(UiMain.this, UiAbout.class);
				// startActivity(intent);
			}
		});
		Btn2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Intent intent = new Intent(UiMain.this, UiAbout.class);
				// startActivity(intent);
			}
		});
		Btn3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Intent intent = new Intent(UiMain.this, UiAbout.class);
				// startActivity(intent);
			}
		});
		Btn4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// Intent intent = new Intent(UiMain.this, UiAbout.class);
				// startActivity(intent);
			}
		});

		// 主视图
		mMainSlidingTabFragment = new MainSlidingTabFragment();
		// 主视图的Fragment添加
		getFragmentManager().beginTransaction()
				.replace(R.id.content_frame, mMainSlidingTabFragment).commit();

		// 左侧菜单
		mMainMenuFragment = new MainMenuFragment();
		// SlidingMenu的配置
		menu = new SlidingMenu(this);
		menu.setMode(SlidingMenu.LEFT);
		menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
		menu.setShadowWidthRes(R.dimen.shadow_width);
		menu.setShadowDrawable(R.drawable.shadow);
		menu.setBehindOffsetRes(R.dimen.slidingmenu_offset);
		menu.setFadeDegree(0.35f);
		menu.attachToActivity(this, SlidingMenu.SLIDING_CONTENT);
		// menu视图的Fragment添加
		menu.setMenu(R.layout.sliding_menu_menu);
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.menu_frame, mMainMenuFragment).commit();

		mAbTitleBar.getLogoView().setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (menu.isMenuShowing()) {
					menu.showContent();
				} else {
					menu.showMenu();
				}
			}
		});

		initTitleRightLayout();

		// 初始化AbSqliteStorage
		mAbSqliteStorage = AbSqliteStorage.getInstance(this);

	}

	// 标题栏右侧按钮
	private void initTitleRightLayout() {
		mAbTitleBar.clearRightView();
		View rightViewMore = mInflater.inflate(R.layout.more_btn, null);
		mAbTitleBar.addRightView(rightViewMore);
		Button about = (Button) rightViewMore.findViewById(R.id.moreBtn);

		about.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(UiMain.this, UiSearch.class);
				startActivity(intent);
			}

		});
	}

	/**
	 * 描述：侧边栏刷新
	 */
	public void updateMenu() {
		mMainMenuFragment.initMenu();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			Intent intent) {
		if (resultCode != RESULT_OK) {
			return;
		}

		// 刷新
		updateMenu();
	}

	/**
	 * 描述：显示这个fragment
	 */
	public void showFragment(Fragment fragment) {
		// 主视图的Fragment添加
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.content_frame, fragment).commit();
		if (menu.isMenuShowing()) {
			menu.showContent();
		}
	}

	public void toLogin(int requestCode) {
		Intent loginIntent = new Intent(this, UiLogin.class);
		startActivityForResult(loginIntent, requestCode);
	}

	@Override
	protected void onPause() {
		initTitleRightLayout();
		AbLogUtil.d(this, "--onPause--");
		// AbMonitorUtil.closeMonitor();
		super.onPause();
	}

	@Override
	protected void onResume() {
		AbLogUtil.d(this, "--onResume--");
		// 如果debug模式被打开，显示监控
		// AbMonitorUtil.openMonitor(this);
		super.onResume();
	}

	@Override
	public void finish() {
		super.finish();

	}

}