package com.can2do.doimmpro.test;

public interface TestDemo {
	
	public void testArray();
	
	public void testArrayList();
}