package com.can2do.doimmpro.util;


import com.can2do.doimmpro.R;
import com.can2do.doimmpro.model.Customer;

import android.content.Context;
import android.content.res.Resources;

public class UIUtil {

	// tag for log
	
	public static String getCustomerInfo (Context ctx, Customer customer) {
		Resources resources = ctx.getResources();
		StringBuffer sb = new StringBuffer();
		sb.append(resources.getString(R.string.customer_blog));
		sb.append(" ");
		sb.append(customer.getBlogcount());
		sb.append(" | ");
		sb.append(resources.getString(R.string.customer_fans));
		sb.append(" ");
		sb.append(customer.getFanscount());
		return sb.toString();
	}
}