package com.can2do.doimmpro.demo.global;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.ab.global.AbAppConfig;
import com.can2do.doimmpro.R;

public class MyApplication extends Application {

	public String cityid = Constant.DEFAULTCITYID;
	public String cityName = Constant.DEFAULTCITYNAME;
	public boolean userPasswordRemember = false;
	public boolean ad = false;
	public boolean isFirstStart = true;
	public SharedPreferences mSharedPreferences = null;

	@Override
	public void onCreate() {
		super.onCreate();
		mSharedPreferences = getSharedPreferences(AbAppConfig.SHARED_PATH,
				Context.MODE_PRIVATE);
		initLoginParams();
	}

	/**
	 * 上次登录参数
	 */
	private void initLoginParams() {
		
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
	}

}
