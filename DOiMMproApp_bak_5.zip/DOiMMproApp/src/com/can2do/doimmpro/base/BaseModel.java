package com.can2do.doimmpro.base;

public class BaseModel {
	
}